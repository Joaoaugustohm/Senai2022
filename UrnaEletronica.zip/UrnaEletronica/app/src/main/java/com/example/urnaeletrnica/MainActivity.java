package com.example.urnaeletrnica;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText cpf, numero_candidato;
    TextView nome, cargo;
    Button verificar, confirmar;
    ArrayList<String> confirmados = new ArrayList<>();
    public static int contador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        cpf = findViewById(R.id.input_cpf);
        numero_candidato = findViewById(R.id.input_num_candidato);
        nome = findViewById(R.id.nome);
        cargo = findViewById(R.id.cargo);
        verificar = findViewById(R.id.verificar);
        confirmar = findViewById(R.id.confirmar);
        nome.setVisibility(View.GONE); // esconder o campo de nome do candidato no OnCreate
        cargo.setVisibility(View.GONE); // esconder o campo de cargo do candidato no OnCreate
        confirmar.setVisibility(View.INVISIBLE);
    }
    public void varrer_cpfs(View v){
        String str_cpf = cpf.getText().toString();
        if (str_cpf.length() == 11) {
            DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("CPFS");
            reference.addValueEventListener(new ValueEventListener(){ // o erro ta aqui
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot){ // até aqui
                    boolean aux = false;
                    Toast.makeText(MainActivity.this, "2.", Toast.LENGTH_LONG).show();
                    for (DataSnapshot d : snapshot.getChildren()) {
                        String cpf_database = d.getValue(CPFS.class).getCpf();
                        Toast.makeText(MainActivity.this, "3.", Toast.LENGTH_LONG).show();
                        if (cpf_database.equals(str_cpf)){
                            aux = true;
                            Toast.makeText(MainActivity.this, "CPF já votou.", Toast.LENGTH_LONG).show();
                            break;
                        }
                    }
                    if (!aux) {
                        CPFS c = new CPFS(str_cpf);
                        c.salvar_cpf();
                        Toast.makeText(MainActivity.this, "teste.", Toast.LENGTH_LONG).show();
                        verificar_presidente();
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) { }
            });
        }
    }
    public void verificar_presidente(){
        nome.setVisibility(View.VISIBLE);
        cargo.setVisibility(View.VISIBLE);
        String str_numero_candidato = numero_candidato.getText().toString();
        int int_numero_candidato = Integer.parseInt(str_numero_candidato);
        if(int_numero_candidato == 13){
            nome.setText("Lula");
            cargo.setText("Presidente - PT");
            confirmar.setVisibility(View.VISIBLE);
        } else if(int_numero_candidato == 22){
            nome.setText("Jair Bolsonaro");
            cargo.setText("Presidente - PL");
            confirmar.setVisibility(View.VISIBLE);
        } else if(str_numero_candidato.length() > 2){
            numero_candidato.setText(null);
            Toast.makeText(this, "Número para voto digitado incorretamente.", Toast.LENGTH_LONG).show();
        } else{
            Toast.makeText(this, "Não há candidato com o número "+str_numero_candidato, Toast.LENGTH_LONG).show();
            numero_candidato.setText(null);
            nome.setVisibility(View.GONE);
            cargo.setVisibility(View.GONE);
        }
    }
    public void confirmar(View c){
        String str_numero_candidato = numero_candidato.getText().toString();
        int int_numero_candidato = Integer.parseInt(str_numero_candidato);
        if(int_numero_candidato == 13){ // adicionar um voto para o Lula
            String str_nome = nome.getText().toString();
            String cargo_firebase = "Presidente - PT";
            contador = contador + 1;
            Candidatos ca = new Candidatos(str_nome, str_numero_candidato, cargo_firebase, contador);
            ca.salvar_presidente();
            Toast.makeText(this, "Voto computado: 13", Toast.LENGTH_LONG).show();
        } else if (int_numero_candidato == 22){ // adicionar um voto para o Bolsonaro
            String str_nome = nome.getText().toString();
            String cargo_firebase = "Presidente - PL";
            contador = contador + 1;
            Candidatos ca = new Candidatos(str_nome, str_numero_candidato, cargo_firebase, contador);
            ca.salvar_presidente();
            Toast.makeText(this, "Voto computado: 22", Toast.LENGTH_LONG).show();
        }
    }
    public void esconder_teclado(View editText) { // esconde o teclado ao clicar fora do cpf
        InputMethodManager imm = (InputMethodManager) this.getSystemService(this.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(editText.getWindowToken(), 0);
    }
}